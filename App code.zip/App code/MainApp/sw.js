var cacheName = 'hi-pwa'; 
var filesToCache = [
'/',    
'/index.html',  
'/main.html',
'/css/loginsheet.css',
'/css/mainsheet.css',  
'/css/style.css',  
'/js/main.js',
'/js/a2hs.js', 
'/js/initializefirestore.js',
'/js/logfunctions.js',
'/js/authenticationsetup.js',
'/js/mainscript.js',
'/js/searchfunctions.js'
 ];  
self.addEventListener('install', function(e) { 
e.waitUntil(
caches.open(cacheName).then(function(cache) { 
return cache.addAll(filesToCache);   
})    
);  
}); 
/* Serve cached content when offline */ 
self.addEventListener('fetch', function(e) {  
e.respondWith(      caches.match(e.request).then(function(response) {  
return response || fetch(e.request);
})   
);  
});