//chart.js functions, replace with highchart
var ctx = document.getElementById('chart');
var myChart;
function makeChart(data){	
  myChart = new Chart(ctx, {
      type: 'bar',
      data: {
	  labels: [rtNames[1], rtNames[2]+"/100", rtNames[4], rtNames[5], rtNames[6], rtNames[7]+"/10", rtNames[8]],
          datasets: [{
              label: 'Realtime data',
              data: [data.airTemperature, data.barometricPressure/100, data.humidity, data.rainfall, data.uvIndex, data.windDirection/10, data.windSpeed],
              backgroundColor: [
                  'rgba(255, 99, 132, 0.2)',
                  'rgba(54, 162, 235, 0.2)',
                  'rgba(255, 206, 86, 0.2)',
                  'rgba(75, 192, 192, 0.2)',
                  'rgba(153, 102, 255, 0.2)',
				  'rgba(100, 122, 255, 0.2)',
                  'rgba(255, 159, 64, 0.2)'
              ],
              borderColor: [
                  'rgba(255, 99, 132, 1)',
                  'rgba(54, 162, 235, 1)',
                  'rgba(255, 206, 86, 1)',
                  'rgba(75, 192, 192, 1)',
                  'rgba(153, 102, 255, 1)',
				  'rgba(200, 106, 96, 1)',
                  'rgba(255, 159, 64, 1)'
              ],
              borderWidth: 1
          }]
      },
      options: {
          scales: {
              yAxes: [{
                  ticks: {
                      beginAtZero: true
                  }
              }]
          }
      }
  });
}

function updateChart(data){
	var updateData=[data.airTemperature, data.barometricPressure/100, data.humidity, data.rainfall, data.uvIndex, data.windDirection/10, data.windSpeed];
    myChart.data.datasets.forEach((dataset)=>{
		dataset.data=updateData;
	});
    myChart.update();	
}