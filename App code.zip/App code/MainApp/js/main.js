//for running the service worker
window.onload = () => { 
'use strict';     
if ('serviceWorker' in navigator) {     
navigator.serviceWorker  
.register('/sw.js'); 
} 
}
console.log("service worker running");

