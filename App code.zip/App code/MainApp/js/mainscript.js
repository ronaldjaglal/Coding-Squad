//keep additional functions here, should contain deleteAccount and extra user support features

//sign out of account and send to login screen
function signout(){
 window.location.replace("login screen.html");	
 firebase.auth().signOut().then(function(){
   alert("You have signed out");
 }).catch(function(error){
   alert("Couldn't sign out properly");
 });	 
}
