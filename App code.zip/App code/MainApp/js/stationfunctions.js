var station;
var logData;
var realtimeData;
var stationDisplay=document.getElementById("stationdisplay");

function displayStation(value){
  stationsList.style.display="none";
  stationDisplay.style.display="inline";  
  station=value;
  var stationName=document.getElementById("stationname");
  logData=document.getElementById("logdata");
  realtimeData=document.getElementById("realtimedata");
  stationName.innerHTML=station.data().name;
  makeChart(station.data());//construct chart
  populateTable(station.data());//populate realtime table
  receiveUpdates();//wait for updates to data
}

function populateTable(data){
  document.getElementById("realtimearea").style.display="inline";
  realtimeData.innerHTML="";
  var headers=document.createElement("tr");
  rtNames.forEach(function(attribute){	  
    var headerName=document.createElement("th");
    headerName.innerHTML=attribute;
	headerName.addEventListener("click", function(){ });
    headers.appendChild(headerName);	
  });
  realtimeData.appendChild(headers);
  var updateData=[data.airQuality, data.airTemperature, data.barometricPressure, data.updatedAt, data.humidity, data.rainfall, data.uvIndex, data.windDirection, data.windSpeed, data.alertConfig,
              data.location, data.name, data.owner, data.status];  
  row=document.createElement("tr");
  data.forEach(function(attribute){
	var value=document.createElement("td");
    value.innerHTML=attribute;
    row.appendChild(value);	  
  });
  realtimeData.appendChild(row);
}

function receiveUpdates(){
 	stationRef.doc(station.id).onSnapshot(function(doc){
		station=doc;
		updateChart(doc.data());
		populateTable(doc.data());
		notify(doc.data());
	});		
}

//hide station
function closeStation(){
  stationDisplay.style.display="none";
  logData.innerHTML="";
  stationsList.style.display="inline";
}

//display log data as a list of logs for a station
function displayLogs(){
  document.getElementById("logbutton").disabled=true;
  populateHeaders();
  stationRef.doc(station.id).collection("logs").get().then(function(querySnapshot){
    querySnapshot.forEach(function(doc){ 
      logData.appendChild(toLog(doc.data()));      
	});//query
	document.getElementById("logbutton").disabled=false;
  });//then			
}

function toLog(log){//convert data to readable format
  this.attributes=[];	
  this.attributes[0]=log.airQuality;//to do, un-map airQuality
  this.attributes[1]=log.airTemperature;
  this.attributes[2]=log.barometricPressure;
  this.attributes[3]=log.createdAt;
  this.attributes[4]=log.humidity;
  this.attributes[5]=log.rainfall;
  this.attributes[6]=log.uvIndex;
  this.attributes[7]=log.windDirection;
  this.attributes[8]=log.windSpeed;	
  var row=document.createElement("tr");
  attributes.forEach(function(value){
    var attributeValue=document.createElement("td");
    attributeValue.innerHTML=value;
    row.appendChild(attributeValue);	
  });
  return row;
}

function populateHeaders(){//add header elements together to populate first row
  logData.innerHTML="";
  var headers=document.createElement("tr");
  attributeNames.forEach(function(attribute){	  
    var headerName=document.createElement("th");
    headerName.innerHTML=attribute;
    headers.appendChild(headerName);	
  });
  logData.appendChild(headers);
}

//add station to favourites
function favouriteStation(){	
  var favouriteArray=[];	
  try{
  var favouriteList=localStorage.getItem("favourites");	
  favouriteArray=favouriteList.split(",");
  for(var i=0;i<favouriteArray.length;i++){
    if(favouriteArray[i]==station.data().name){
		favouriteArray[i]=favouriteArray[favouriteArray.length-1];
		favouriteArray.pop();
		localStorage.setItem("favourites",favouriteArray.toString());
	    return;
	}
  }
  }catch(err){}
  favouriteArray.push(station.data().name);
  localStorage.setItem("favourites",favouriteArray.toString());
}