var searchBar=document.getElementById("searchbar");
var criteriaButton=document.getElementById("criteriabutton");
var stationRef=db.collection("weather_stations");
var stationsList=document.getElementById("stationslist");
var listHeader=document.getElementById("listheader");

//listen for "enter key" on search bar to run functions
searchbar.addEventListener("keyup",function(event){
  if(event.keyCode===13){
    event.preventDefault(); 
	listHeader.innerHTML="Stations list";
	search();
  }	
});

//this functions changes the search criteria based on the criteria button
function changeCriteria(){
  if(criteriaButton.value=="location")
    criteriaButton.value="name";		
  else
    criteriaButton.value="location"; 	  
}


//This function initiates the location search
function search(){
  var value=searchbar.value;
  searchBar.value="";
  if(criteriaButton.value=="location")
    searchByLocation(value);
  else
	searchByName(value);  
}

//functions to search firestore for relevent data and display it in "stations list"
function searchByLocation(value){//search display stations by location
	
}

function searchByName(value){//search for stations by name and display stations by name and id
	listHeader.innerHTML='Results for '+'"'+value+'"';
	stationsList.innerHTML="";
	stationRef.where("name","==",value).get().then(function(querySnapshot){//querying function
	  querySnapshot.forEach(function(doc){ 
	    var stationData=document.createElement("p");
		stationData.innerHTML="id:"+doc.id+" name:"+doc.data().name;
		stationData.onclick=function(){ displayStation(doc);};//display a station when station is clicked
	    stationsList.appendChild(stationData);
	  });//query	 
	}).catch(function(error){	    
	});//catch
}

//get favourite stations
function getFavourites(){
	var favouriteArray=[];
	//retrieve stations from web storage
	try{
	  var favouriteList=localStorage.getItem("favourites");
	  favouriteArray=favouriteList.split(",");
	}catch(err){}
	stationsList.innerHTML="";
	listHeader.innerHTML="Favourites";
	//retrieve stations from firebase
	for(var i=0;i<favouriteArray.length;i++){
	 stationRef.where("name","==",favouriteArray[i]).get().then(function(querySnapshot){
	   querySnapshot.forEach(function(doc){ 
	     var stationData=document.createElement("p");
		 stationData.innerHTML="id:"+doc.id+" name:"+doc.data().name;
		 stationData.onclick=function(){ displayStation(doc);};
	     stationsList.appendChild(stationData);
	  });//query	 
	}).catch(function(error){	    
	});//catch
	}	
}