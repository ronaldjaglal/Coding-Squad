//stores relevant attribute names as string arrays

//log attributes
var attributeNames=[
  "airQuality",
  "airTemperature",
  "barometricPressure",
  "createdAt",
  "humidity",
  "rainfall",
  "uvIndex",
  "windDirection",
  "windSpeed"
	  ];
	  
//station attributes	  
var rtNames=[
  "airQuality",
  "airTemperature",
  "barometricPressure",
  "updatedAt",
  "humidity",
  "rainfall",
  "uvIndex",
  "windDirection",
  "windSpeed",
  "alertConfig",
  "location",
  "name",
  "owner",
  "status"
];