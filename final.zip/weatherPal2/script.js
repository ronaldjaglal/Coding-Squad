//manages the navigator
//is also responsible for the tabs in index
//sidenav
  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.sidenav');
    var instances = M.Sidenav.init(elems, {});
  });

//Jquery for swipeable tabs and parrallax
$(document).ready(function(){
    $('ul.tabs').tabs({
      swipeable : true,
      responsiveThreshold : 3000
    });
    
    $('.parallax').parallax();
  });

