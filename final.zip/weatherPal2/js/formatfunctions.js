//Used for formatting realtime data for ease of use
//array of stored realtime data retrieved from firestore
function getRealtimeDataArray(data){
  var array=[data.airQuality["aqi10"], data.airQuality["aqi2_5"],
             data.airQuality["pm10"], data.airQuality["pm2_5"],
             data.airTemperature, data.barometricPressure, 
			 data.updatedAt.toDate(), data.humidity, data.rainfall, data.uvIndex, 
			 data.windDirection, data.windSpeed, data.alertConfig,
             "lat:"+data.location.latitude+"<br/>lon:"+data.location.longitude, 
			 data.name, data.owner, data.status];
  return array;		  
}
//stores relevant attribute names as string arrays