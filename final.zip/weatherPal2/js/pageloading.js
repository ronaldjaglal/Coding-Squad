//for loading certain page elements
 //page loading functions for respective pages
 //id is saved between pages for getting station data
var stationid=parent.document.URL.substring(parent.document.URL.indexOf('?')+1, parent.document.URL.length);
function initiateSignout(){
  var enblSignout= function(signedIn){
    if(signedIn){
      document.getElementById("signout").style.display="inline";
      document.getElementById("signout").style.width="100%";
      }
  }
  checkLogin(enblSignout);
}


      