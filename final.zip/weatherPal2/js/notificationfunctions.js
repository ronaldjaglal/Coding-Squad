//keep notification as widgets that can be removed or edited

//load notifications automatically
loadNotifications();

function loadNotifications(){
	
}

function addNotification(){
  
  
}

function removeNotification(){
	
	
	
}

function notify(data){
	
}

