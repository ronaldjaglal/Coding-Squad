//functions associated with with Yahoo
//mainly for setting up Yahoo login

//login to Yahoo
function yahooLogin(){
var provider = new firebase.auth.OAuthProvider('yahoo.com');//get provider
//additional options
provider.setCustomParameters({
  prompt: 'login',
  language: 'en'
});

//sign in
firebase.auth().signInWithPopup(provider).then(function(result){
	window.location.replace("index.html");//redirect url
	}).catch(function(exception){
		alert(exception);
		});
}