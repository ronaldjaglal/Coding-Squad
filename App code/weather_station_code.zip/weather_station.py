import time
import math
import statistics
import schedule
import json
import datetime
import calendar
import firebase_admin
import sensors.bme280_sensor as bme280_sensor
import sensors.wind_direction as wind_direction
import sensors.air_quality as air_quality
from sensors.sds011 import *
#from sensors.rainfall import get_rainfall, reset_rainfall
from gpiozero import Button
from firebase_admin import credentials
from firebase_admin import firestore

# Use a service account
cred = credentials.Certificate('serviceAccount.json')
firebase_admin.initialize_app(cred)

db = firestore.client()
logfile = 'logs.ljson'
station_ref = db.collection(u'weather_stations').document(u'zoQs1B60bxR2OPtEFB6f')
logsRef = station_ref.collection(u'logs')
wind_count = 6            # Counts how many half-rotations
radius_cm = 9.0           # Radius of anemometer 
interval = 280            # Take readings every 5minute (air quality takes 20 seconds) 
wind_interval = 5         # How often (secs) to report speed
CM_IN_KM = 100000.0       # Centimeters in a kilometer
SECS_IN_HOUR = 3600       # Seconds in a hour
ANEMOMETER_FACTOR = 1.18  # Adjustment to account for some wind energy lost when arms turn

wind_speed_sensor = Button(5)
store_speeds = []
store_directions = []

#rain
rain_sensor = Button(6)
BUCKET_SIZE = 0.2794
count = 0
rainfall = 0

wind_gust = 0

def bucket_tipped():
    time.sleep(1)#to avoid extra button presses
    global count
    count = count + 1
    #print(get_rainfall())

def reset_rainfall():
    global count
    count = 0
    
def get_rainfall():
    return count * BUCKET_SIZE


rain_sensor.when_pressed = bucket_tipped
aq_sensor = SDS011("/dev/ttyUSB0")
# Every half-rotation, add 1 to count
def spin():
    global wind_count
    wind_count = wind_count + 1
    # print("spin" + str(wind_count))


# Calculate the wind speed
def calculate_speed(time_sec):
    global wind_count
    circumference_cm = (2 * math.pi) * radius_cm
    rotations = wind_count / 2.000
    
    # Calculate distance travelled by a cup in kilometers
    distance_km = (circumference_cm * rotations) / CM_IN_KM
    
    # Calculate speed in kilometers per hour
    speed = ((distance_km / time_sec) * SECS_IN_HOUR) * ANEMOMETER_FACTOR
    
    return speed

def reset_wind():
    global wind_count
    wind_count = 0
    
def writeData(data, logfile):

    with open(logfile, 'a') as outFile:
        line = json.dumps(data)
        outFile.write(line+"\n")


def loadData(logfile):
    table = []
    try:
        with open(logfile, 'r') as f:
            for line in f:
                table.append(json.loads(line))
    except:
        clearData(logfile)
    return table


def clearData(logfile):
    open(logfile, 'w').close()


def updateLog(logsRef, logfile):
    #clear hourly cumulative rainfall
    reset_rainfall()
    rainfall = 0
    #clear gust
    gust = 0
    try:
        x = loadData(logfile)
        airtempMin = x[0].get(u'airTemperature')
        airtempMax = x[0].get(u'airTemperature')
        gust = x[0].get(u'gust')
        print(x)
        d1 = {}
        from collections import Counter
        for i in range(len(x)):
            try:
                if airtempMax < x[i].get(u'airTemperature'):
                    airtempMax = x[i].get(u'airTemperature')
                if airtempMin > x[i].get(u'airTemperature'):
                    airtempMin = x[i].get(u'airTemperature')
                if gust < x[i].get(u'gust'):
                    gust = x[i].get(u'gust')
                d1 = dict(Counter(d1) + Counter(x[i]))
            except:
                clearData(logfile)
            d2 = {key: d1[key] // len(x) for key in d1.keys() if key != 'j'}
        date = datetime.datetime.utcnow()
        
        months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

        year = str(date.year).encode("utf-8").decode("utf-8")
        month = (months[date.month-1]).encode("utf-8").decode("utf-8")

        timestamp = str(calendar.timegm(date.utctimetuple())).encode("utf-8").decode("utf-8")
        
        logdata = {timestamp: {
                                u'a': d2.get(u'pm10'),
                                u'b': d2.get(u'pm2_5'),
                                u'c': d2.get(u'aqi10'),
                                u'd': d2.get(u'aqi2_5'),
                                u'e': airtempMin,
                                u'f': airtempMax,
                                u'g': d2.get(u'airTemperature'),
                                u'h': d2.get(u'barometricPressure'),
                                u'i': d2.get(u'humidity'),
                                u'j': d2.get(u'rainfall'),
                                u'k': d2.get(u'windDirection'),
                                u'l': gust,
                                u'm': d2.get(u'windSpeed'),
                                }}
        print(logdata)
        logsRef.document(month+"_"+year).set(logdata, merge=True)
        clearData(logfile)
    except:
        pass

schedule.every().hour.do(updateLog,logsRef, logfile)
wind_speed_sensor.when_pressed = spin
# Loop to measure wind speed and report at 5-minute intervals
while True:
    try:
        schedule.run_pending()
        store_speeds.clear()
        store_directions.clear()
        start_time = time.time()
        
        #reset non-cumulative values
        aqi10 = aqi25 = pm10 = pm25 = ambient_temp = pressure = humidity = wind_average = wind_speed = uvIndex = 0
        
        while (time.time() - start_time) <= interval:
            wind_start_time = time.time()
            reset_wind()
            #time.sleep(wind_interval) 
            while time.time() - wind_start_time <= wind_interval:
                    store_directions.append(wind_direction.get_value())
                    
            final_speed = calculate_speed(wind_interval)
            store_speeds.append(final_speed)
        wind_average = wind_direction.get_average(store_directions)
        wind_speed = statistics.mean(store_speeds)
        hi = max(store_speeds)
        if wind_gust < hi:
            wind_gust = hi
        rainfall = get_rainfall()
        humidity, pressure, ambient_temp = bme280_sensor.read_all()
       
        pm25, pm10, aqi25, aqi10 = air_quality.get_pm_aqi(aq_sensor)
        
        aqi10 = round(aqi10, 1)
        aqi25 = round(aqi25, 1)
        pm10 = round(pm10, 1)
        pm25 = round(pm25, 1)
        ambient_temp = round(ambient_temp, 1)
        pressure = round(pressure, 1)
        humidity = round(humidity, 1)
        rainfall = round(rainfall, 1)
        wind_average = round(wind_average, 1)
        wind_speed = round(wind_speed, 1)
        wind_gust = round(wind_gust, 1)
        uvIndex = round(uvIndex, 1)
        
        print(wind_speed, rainfall, wind_average, uvIndex, humidity, pressure, ambient_temp, pm25, pm10, aqi25, aqi10)
        
        dataset = {u'airQuality': {u'aqi10': aqi10, u'aqi2_5': aqi25, u'pm10': pm10, u'pm2_5': pm25},
                            u'airTemperature': ambient_temp,
                            u'barometricPressure': pressure,
                            u'humidity': humidity,
                            u'rainfall': rainfall,
                            u'updatedAt': firestore.SERVER_TIMESTAMP,
                            u'windDirection': wind_average,
                            u'windSpeed': wind_speed,
                            u'gust': wind_gust,
                            u'uvIndex': uvIndex}
        logdata = {
                    u'aqi10': aqi10,
                    u'aqi2_5': aqi25,
                    u'pm10': pm10,
                    u'pm2_5': pm25,
                    u'airTemperature': ambient_temp,
                    u'barometricPressure': pressure,
                    u'humidity': humidity,
                    u'rainfall': rainfall,
                    u'windDirection': wind_average,
                    u'windSpeed': wind_speed,
                    u'gust': wind_gust,
                    u'uvIndex': uvIndex}
        station_ref.set(dataset,merge=True)
        writeData(logdata, logfile)
        #print("Synced")
        
    except:
        pass
    


