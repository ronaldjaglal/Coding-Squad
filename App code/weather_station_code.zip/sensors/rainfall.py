from gpiozero import Button
import time

rain_sensor = Button(6)
BUCKET_SIZE = 0.2794
count = 0


def bucket_tipped():
    global count
    count = count + 1
    print(get_rainfall())

def reset_rainfall():
    global count
    count = 0
    
def get_rainfall():
    return count * BUCKET_SIZE


rain_sensor.when_pressed = bucket_tipped
