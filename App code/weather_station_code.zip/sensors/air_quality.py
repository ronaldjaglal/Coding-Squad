import time
import aqi

def get_data(sensor,n = 5):
    # Turn-on sensor
    sensor.sleep(sleep=False)
    pm25 = 0
    pm10 = 0
    # Wait for at least 10 seconds for stabilization before measuring
    time.sleep(10)
    for i in range (n):
        x = sensor.query()
    # Take the sum of n readings
        pm25 = pm25 + x[0]
        pm10 = pm10 + x[1]
    # Wait for at least 2 seconds for stabilization between readings
        time.sleep(2)
    # Calculate average from n readings
    pm25 = round(pm25/n, 1)
    pm10 = round(pm10/n, 1)
    # Turn-off sensor
    sensor.sleep(sleep=True)
    return pm25, pm10

def conv_aqi(pm25, pm10):
    aqi25 = aqi.to_iaqi(aqi.POLLUTANT_PM25, str(pm25))
    aqi10 = aqi.to_iaqi(aqi.POLLUTANT_PM10, str(pm10))
    return float(aqi25), float(aqi10)

def get_pm_aqi(sensor):
    pm25, pm10 = get_data(sensor)
    #print("PM2.5:",pmt_2_5," PM10:",pmt_10)
    aqi25, aqi10 = conv_aqi(pm25, pm10)
    #print("AQI2.5:",aqi_2_5," AQI10:",aqi_10)
    return pm25, pm10, aqi25, aqi10
