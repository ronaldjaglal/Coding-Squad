importScripts("https://www.gstatic.com/firebasejs/7.12.0/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/7.12.0/firebase-messaging.js");
importScripts("https://www.gstatic.com/firebasejs/7.12.0/firebase-analytics.js");

var firebaseConfig = {
    apiKey: "AIzaSyDk89w1bx6kZTmIcYEw79sUDfmFLYeIAoY",
    authDomain: "weatherpal-f300b.firebaseapp.com",
    databaseURL: "https://weatherpal-f300b.firebaseio.com",
    projectId: "weatherpal-f300b",
    storageBucket: "weatherpal-f300b.appspot.com",
    messagingSenderId: "291721522633",
    appId: "1:291721522633:web:84aa7f85de968fbb194c18",
    measurementId: "G-S4C6D8JDD5"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();

messaging.setBackgroundMessageHandler(payload => {
    const notification = JSON.parse(payload.data.notification);
const notificationTitle = notification.title;
const notificationOptions = {
    body: notification.body
};
//Show the notification :)
return self.registration.showNotification(
    notificationTitle,
    notificationOptions
);
});