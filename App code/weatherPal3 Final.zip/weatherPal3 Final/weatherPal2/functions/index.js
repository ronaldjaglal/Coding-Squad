const functions = require('firebase-functions');
const admin = require('firebase-admin');

admin.initializeApp(functions.config().firebase);

const db = admin.firestore();

exports.sendStationAlerts = functions.firestore.document('weather_stations/{stationId}').onWrite(async (event, context) => {

    let station_data = event.after.data();
    var alertsRef = db.collection('weather_stations').doc(context.params.stationId).collection('alerts');
    var allalerts = alertsRef.get()
    // eslint-disable-next-line promise/always-return
        .then(snapshot => {
            snapshot.forEach(doc => {
                let alertData = doc.data();
                let userid = doc.id;
                let mbody = "";
                let valuetypes = Object.keys(alertData);
                for(let k = 0; k < valuetypes.length;k++)
                {
                    let valuetype = valuetypes[k];
                    if(alertData[valuetype].hasOwnProperty('enabled'))
                        if (alertData[valuetype]['enabled'] === true)
                        {
                            if(valuetype === 'pm2_5')
                            {
                                let current = station_data['airQuality'][valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "PM2.5: " + current + "µg/m³\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "PM2.5: " + current + "µg/m³\n";
                                    }
                                }

                            }
                            else if(valuetype === 'pm10')
                            {
                                let current = station_data['airQuality'][valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "PM10: " + current + "µg/m³\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "PM10: " + current + "µg/m³\n";
                                    }
                                }
                            }

                            else if(valuetype === 'aqi2_5')
                            {
                                let current = station_data['airQuality'][valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "AQI2.5:: " + current + "\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "AQI2.5:: " + current + "\n";
                                    }
                                }
                            }

                            else if(valuetype === 'aqi10')
                            {
                                let current = station_data['airQuality'][valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "AQI10: " + current + "\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "AQI10: " + current + "\n";
                                    }
                                }
                            }

                            else if(valuetype === 'airTemperature')
                            {
                                let current = station_data[valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "Ambient Temperature: " + current + "°C\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "Ambient Temperature: " + current + "°C\n";
                                    }
                                }
                            }

                            else if(valuetype === 'barometricPressure')
                            {
                                let current = station_data[valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "Atmospheric Pressure: " + current + "hPa\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "Atmospheric Pressure: " + current + "hPa\n";
                                    }
                                }
                            }

                            else if(valuetype === 'gust')
                            {
                                let current = station_data[valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "Wind Gust:" + current + "km/h\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "Wind Gust:" + current + "km/h\n";
                                    }
                                }
                            }

                            else if(valuetype === 'humidity')
                            {
                                let current = station_data[valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "Humidity: " + current + "%\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "Humidity: " + current + "%\n";
                                    }
                                }
                            }

                            else if(valuetype === 'rainfall')
                            {
                                let current = station_data[valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "Rainfall: " + current + "mm\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "Rainfall: " + current + "mm\n";
                                    }
                                }
                            }

                            else if(valuetype === 'uvIndex')
                            {
                                let current = station_data[valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "UV Index: " + current + "\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "UV Index: " + current + "\n";
                                    }
                                }
                            }

                            else if(valuetype === 'windDirection')
                            {
                                let current = station_data[valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    let val = Math.round(current/22.5);
                                    let arr = ["N","NNE","NE","ENE","E","ESE", "SE", "SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"];
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "Wind Direction: " + current + "° (" + arr[val % 16] +")\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "Wind Direction: " + current + "° (" + arr[val % 16] +")\n";
                                    }
                                }
                            }

                            else if(valuetype === 'windSpeed')
                            {
                                let current = station_data[valuetype].toFixed(1);
                                if(alertData[valuetype]['in_range'])
                                {
                                    if(current <= alertData[valuetype]['max']
                                        && current >= alertData[valuetype]['min'])
                                    {
                                        mbody += "Wind Speed: " + current + "km/h\n";
                                    }
                                }
                                else
                                {
                                    if(current >= alertData[valuetype]['max']
                                        || current <= alertData[valuetype]['min'])
                                    {
                                        mbody += "Wind Speed: " + current + "km/h\n";
                                    }
                                }
                            }
                        }

                }
                if(mbody !== "")
                {
                    let userRef = db.collection('users').doc(userid);
                    userRef.get().then((doc) => {
                        if (doc.exists) {
                            let fcmTokens = doc.data()['fcm'];

                            var message = {
                                notification: {
                                    title: "Alert from " + station_data['name'],
                                    body: mbody,
                                },
                            };
                            return admin.messaging().sendToDevice(fcmTokens, message).then(response => {
                                // For each message check if there was an error.
                                const tokensToRemove = [];
                                response.results.forEach((result, index) => {
                                    const error = result.error;
                                    if (error) {
                                        console.error('Failure sending notification to', fcmTokens[index], error);
                                        // Cleanup the tokens who are not registered anymore.
                                        if (error.code === 'messaging/invalid-registration-token' ||
                                            error.code === 'messaging/registration-token-not-registered') {
                                            tokensToRemove.push(userRef.update({fcm: admin.firestore.FieldValue.arrayRemove(fcmTokens[index])}));
                                        }
                                    }
                                });
                                return Promise.all(tokensToRemove);
                            });
                        } else {
                            // doc.data() will be undefined in this case
                            throw new Error("No such user!");
                        }
                    }).catch((error) => {
                        console.log("Error getting user:", error);
                    });
                }


            });
        })
        .catch(err => {
            console.log('Error getting alerts', err);
        });
});