
//functions on user object

//get firestore instance
var db=getFirestoreInstance();

//save user to a collection in firestore
function saveUserDoc(user){
	//modify the user data in the user's doc
    var userData={ 
      id:user.uid, 
      name:user.displayName
     };      
    updateDoc(db.collection("users").doc(user.uid), userData); //make the user document
}

