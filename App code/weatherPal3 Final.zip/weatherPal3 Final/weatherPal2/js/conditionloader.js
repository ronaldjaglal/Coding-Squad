// //retrieve and display condition value
// //gauge is gauge to display
// //container is containing element for gauge
// //conditionNumber is used for retrieving condition
// function loadConditions(gauge, container, conditionNumber){ //facade for loading in condtion values
//   loadGauge(gauge, container);
//   var updater=function (conditions){
//     document.getElementById("condition").innerHTML=conditions[conditionNumber];
//     loadFromData(data.data());
//    }
//    receiveData(stationid, updater);
// }