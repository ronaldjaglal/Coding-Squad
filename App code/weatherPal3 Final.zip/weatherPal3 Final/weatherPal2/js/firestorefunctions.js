//General firestore functions
//save to firestore
function saveToFirestore(collRef, object, callback=null){
  collRef.add(object).then(function(docRef){
    console.log("Write successful");
    if(callback)
      callback(docRef);
  }).catch(function(error){
     console.log("Error writing to firestore");
     if(callback)
       callback(null);
  });
}

//update a doc reference
function updateDoc(docRef, object, callback=null){
  docRef.set(object, {merge:true}).then(function(docRef){
    console.log("Write successful");
    if(callback)
      callback(docRef);
  }).catch(function(error){
     console.log("Error writing to firestore");
     if(callback)
       callback(null);
  });
}