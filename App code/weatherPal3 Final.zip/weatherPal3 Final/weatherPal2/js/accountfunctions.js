//holds account functions
//responsibilities involve functions on user's account which relate to authentication
firebase.auth(); //call to firebase authentication to prevent issues where waiting for call causes problems.
//allows a user to delete their account
function deleteAccount(){  
  try{
    firebase.auth().currentUser.delete();
  }catch(exception){return false;}
  return true;
}

//gets the current user
//takes a callback function
function getUser(callback){
	firebase.auth().onAuthStateChanged(function(user) {
    callback(user);
  });
}

//allows the user to change their password
function changePassword(newPassword){
  try{
    firebase.auth().currentUser.updatePassword(newPassword);
  }catch(exception){return false;}
  return true;
}

//sign out of account and send to login screen
function signout(){	
  try{
    firebase.auth().signOut();
  }catch(exception){return false;}
   return true;
}