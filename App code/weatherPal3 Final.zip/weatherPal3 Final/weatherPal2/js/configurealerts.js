window.onload = function() {
    getUser(function(user){
        loadUserAlertData(stationid,user.uid);}
    )
}
let serverAlertData = {};
let localAlertData = {};


const alertElemSubId = ["pm10", "aqi10", "pm25","aqi25","temp", "pressure","gust",
    "humidity","rainfall", "uvIndex", "windSpeed", "windDir"];

function id_conv(alert_id)
{
    if(alert_id === alertElemSubId[0]) return 'pm10';
    if(alert_id === alertElemSubId[1]) return 'aqi10';
    if(alert_id === alertElemSubId[2]) return 'pm2_5';
    if(alert_id === alertElemSubId[3]) return 'aqi2_5';
    if(alert_id === alertElemSubId[4]) return 'airTemperature';
    if(alert_id === alertElemSubId[5]) return 'barometricPressure';
    if(alert_id === alertElemSubId[6]) return 'gust';
    if(alert_id === alertElemSubId[7]) return 'humidity';
    if(alert_id === alertElemSubId[8]) return 'rainfall';
    if(alert_id === alertElemSubId[9]) return 'uvIndex';
    if(alert_id === alertElemSubId[10]) return 'windSpeed';
    if(alert_id === alertElemSubId[11]) return 'windDirection';
}

function get_range(alert_id)
{
    if(alert_id === alertElemSubId[0]) return {
        'min': 0,
        'max': 604
    };
    if(alert_id === alertElemSubId[1])  return {
        'min': 0,
        'max': 500
    };
    if(alert_id === alertElemSubId[2])  return {
        'min': 0,
        'max': 501
    };
    if(alert_id === alertElemSubId[3])  return {
        'min': 0,
        'max': 500
    };
    if(alert_id === alertElemSubId[4])  return {
        'min': -40,
        'max': 85
    };
    if(alert_id === alertElemSubId[5])  return {
        'min': 300,
        'max': 1100
    };
    if(alert_id === alertElemSubId[6])  return {
        'min': 0,
        'max': 400
    };
    if(alert_id === alertElemSubId[7])  return {
        'min': 0,
        'max': 100
    };
    if(alert_id === alertElemSubId[8])  return {
        'min': 0,
        'max': 80
    };
    if(alert_id === alertElemSubId[9])  return {
        'min': 0,
        'max': 12
    };
    if(alert_id === alertElemSubId[10])  return {
        'min': 0,
        'max': 400
    };
    if(alert_id === alertElemSubId[11])  return {
        'min': 0,
        'max': 360
    };
}




function setupConfig(alertType, slider, toggle, options, select)
{
    let start = [];
    let condition = true;
    let range = get_range(alertType);
    let key = id_conv(alertType);
    if (serverAlertData != null && key in serverAlertData)
    {
        start.push(serverAlertData[key]['min']);
        start.push(serverAlertData[key]['max']);
        if ('in_range' in serverAlertData[key]) condition = serverAlertData[key]['in_range'];
    }
    else
    {
        let mid  = (Math.abs(range['max']) - Math.abs(range['min'])) / 2;
        start = [mid , mid];
    }

    try {
        slider.noUiSlider.destroy();
    } catch (e) {

    }

    noUiSlider.create(slider, {
        start: start,
        connect: true,
        tooltips: [ wNumb({ decimals: 0 })  , wNumb({ decimals: 0 }) ],

        range:range
    }).on('update', function( values, handle ) {
        updateLocalData(alertType, 'min', values[0]);
        updateLocalData(alertType, 'max', values[1]);
    });

    if (condition)
    {
        select.selectedIndex = 0;
        updateLocalData(alertType,'in_range', true);
        select.parentNode.classList.add("has-success");
    }
    else
    {
        select.selectedIndex = 1;
        updateLocalData(alertType,'in_range', false);
        select.parentNode.classList.add("has-warning");
    }

    select.onchange = function()
    {
        select.parentNode.classList.remove("has-success", "has-warning");
        if (select.selectedIndex === 1)
        {
            updateLocalData(alertType,'in_range', false);
            select.parentNode.classList.add("has-warning");
        }
        if (select.selectedIndex ===  0)
        {
            updateLocalData(alertType,'in_range', true);
            select.parentNode.classList.add("has-success");
        }
    };

    toggle.addEventListener('input', function () {
        if(this.checked)
        {
            options.style.display = "block";
            updateLocalData(alertType, 'enabled', true)
        }
        else
        {
            options.style.display = "none";
            updateLocalData(alertType, 'enabled', false)
        }

    });

    // if alert in serverData turn on
    if(serverAlertData != null && key in serverAlertData)if(serverAlertData[key]['enabled'])toggle.checked = 'checked';

    // Toggle back and forth to init even listener
    toggle.click();
    toggle.click();
}

function updateLocalData(alertid, key, value)
{
    let sid = id_conv(alertid);
    buildObject(localAlertData,[sid,key],value)
}

function buildObject(obj, keyPath, value) {
    let lastKeyIndex = keyPath.length - 1;
    for (let i = 0; i < lastKeyIndex; ++ i)
    {
        let key = keyPath[i];
        if (!(key in obj)){
            obj[key] = {}
        }
        obj = obj[key];
    }
    obj[keyPath[lastKeyIndex]] = value;
}



function loadUserAlertData(stationid, userid)
{
    let db = getFirestoreInstance();
    db.collection("weather_stations").doc(stationid).collection("alerts").doc(userid).onSnapshot(function(doc)
    {
        serverAlertData = doc.data();
        alertElemSubId.forEach(item =>
        {
            let toggleId = "#"+item+"-toggle"
            let sliderId = "#"+item+"-slider"
            let optionsId = "#"+item+"-options"
            let selectId  = "#"+item+"-select"
            let toggle = document.getElementById(toggleId);
            let slider = document.getElementById(sliderId);
            let options = document.getElementById(optionsId);
            let select = document.getElementById(selectId);
            setupConfig(item, slider, toggle, options, select);
        });
    });
}

function updateUserAlertData(stationid, userid)
{
    let db = getFirestoreInstance();
    db.collection("weather_stations").doc(stationid).collection("alerts").doc(userid).set(
        localAlertData,{merge:false}
    );
}

$("#alert-confirm").click( function () {
    getUser(function(user){
        updateUserAlertData(stationid, user.uid);
    })});
// $("#alert-modal-toggle").click(function () {
//     getUser(function(user){
//         loadUserAlertData(stationid,user.uid);}
//         )});