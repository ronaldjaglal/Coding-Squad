//holds functions involving the manipulation of station data received from firebase
var data;//holds current station data
var stationid;
var db=getFirestoreInstance(); //necessary for firestore functions
var stationRef=db.collection("weather_stations");

//update the station referrence of pages for retrieving data
function updatePages(doc){
	listHeader.innerHTML="Navigate to get conditions at "+doc.data().name;
	stationsList.innerHTML="";
	stationid=doc.id;
	window.location.href="index.html?"+stationid;
	}
	
function receiveData(stationid, updater){//receive data from a station
	var ref=stationRef.doc(stationid);
	ref.get().then(function(doc){
		data=doc;
		updater(); //update condition at this page
		});
	receiveUpdates(stationid, updater);
	}

//receive contiuous updates to data
function receiveUpdates(stationid, updater){//sets up a listener that activates every time log data is updated
 	stationRef.doc(stationid).onSnapshot(function(doc){ //function to listen for updates
		data=doc;
		updater();
	});		
}


