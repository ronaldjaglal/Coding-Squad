
var db=getFirestoreInstance();
const stationsRef = db.collection("weather_stations");

function addto_favorites(user_id, station_id){
    var userRef = db.collection("users").doc(user_id);
    userRef.set({favorites: firebase.firestore.FieldValue.arrayUnion(station_id)},{merge: true});
    alert("Added to favourites");
}

// apart from when user wants to remove,
// call this when an attempt to access a deleted station that was in favorites is made
function remove_favorite(user_id, station_id)
{
    var userRef = db.collection("users").doc(user_id);
    userRef.update({favorites: firebase.firestore.FieldValue.arrayRemove(station_id)});
    alert("Removed from favourites");
}

function set_owner(station_id, owner_id)
{
    var ownerRef = db.collection("users").doc(owner_id);

    // update station doc
    stationsRef.doc(station_id).set({owner: owner_id,
        // status = 0 means unregistered
        // status = 2 means registered and disabled
        status: 1} //registered and enabled
        , {merge: true});

    // update user doc
    ownerRef.set({owned: firebase.firestore.FieldValue.arrayUnion(station_id)},{merge: true});
}

//this should only be used by logged in owners
//access is already handled in the firestore rules
//the rest will be handled on the pi
function disable_enable_station(unique_station_code, val)
{
	var query = stationsRef.where("uid", "==", unique_station_code);
	query.get().then(function(querySnapshot){
	  querySnapshot.forEach(function(doc){
        stationsRef.doc(doc.id).set({
        // val = 1 enabled
        // val = 2 disabled
        status: val}, {merge:true});
        if(val===1 ) 
          alert("Station enabled");
        else
          alert("Station disabled");
    });  //snapshot
    }); //query
}

function add_station(unique_station_code , authuser_uid)
{
    var query = stationsRef.where("uid", "==", unique_station_code);
    query.get().then(function(querySnapshot) {
        //only runs when station matched and found
            querySnapshot.forEach(function(doc) {
                //if unregistered
                if (doc.data()['status'] === 0) {
                  set_owner(doc.id, authuser_uid);
                  alert("Added successfully");
                 }
                 else
                   alert("Station already registered");                 
            });
        })
        .catch(function(error) {
            console.log("Error getting documents: ", error);
        });
}

