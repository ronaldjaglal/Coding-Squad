// Variables for gauge data
var windSpeed = [0];
var windDirection = [0];
var pm10 = [0];
var pm25 = [0];
var aqi10 = [0];
var aqi25 = [0];
var rainfall = [0];
var pressure = [0];
var humidity = [0];
var temperature = [0];
var uv = [0];


function initcollapse()
{
    $('.collapse').collapse();
}
function updateGaugeData(chart, data)
{
    setInterval(function () {
        var point = chart.series[0].points[0];
        point.update(data[0]);
    }, 1000);
};

function setTextColour(colour)
{
    Highcharts.setOptions(
        {

            title: {
                style:
                    {
                        color: colour,
                    },
            },
            plotOptions: {
                series: {
                    dataLabels: {
                        color: colour
                    },
                }
            },
            xAxis:
                {
                    title:
                        {
                            style:
                                {
                                    color: colour,
                                }
                        },
                    labels: {
                        style:
                            {
                                color: colour
                            },
                    }
                },
            yAxis:
                {
                    title:
                        {
                            style:
                                {
                                    color: colour,
                                }
                        },
                    labels: {
                        style:
                            {
                                color: colour
                            },
                    }
                },


        });
}


function setupLinearGauges(H)
{
    var defaultPlotOptions = H.getOptions().plotOptions,
        columnType = H.seriesTypes.column,
        wrap = H.wrap,
        each = H.each;

    defaultPlotOptions.lineargauge = H.merge(defaultPlotOptions.column, {});
    H.seriesTypes.lineargauge = H.extendClass(columnType, {
        type: 'lineargauge',
        //inverted: true,
        setVisible: function () {
            columnType.prototype.setVisible.apply(this, arguments);
            if (this.markLine) {
                this.markLine[this.visible ? 'show' : 'hide']();
            }
        },
        drawPoints: function () {
            // Draw the Column like always
            columnType.prototype.drawPoints.apply(this, arguments);

            // Add a Marker
            var series = this,
                chart = this.chart,
                inverted = chart.inverted,
                xAxis = this.xAxis,
                yAxis = this.yAxis,
                point = this.points[0], // we know there is only 1 point
                markLine = this.markLine,
                ani = markLine ? 'animate' : 'attr';

            // Hide column
            point.graphic.hide();

            if (!markLine) {
                var path = inverted ? ['M', 0, 0, 'L', -5, -5, 'L', 5, -5, 'L', 0, 0, 'L', 0, 0 + xAxis.len] : ['M', 0, 0, 'L', -5, -5, 'L', -5, 5,'L', 0, 0, 'L', xAxis.len, 0];
                markLine = this.markLine = chart.renderer.path(path)
                    .attr({
                        fill: series.color,
                        stroke: series.color,
                        'stroke-width': 1
                    }).add();
            }
            markLine[ani]({
                translateX: inverted ? xAxis.left + yAxis.translate(point.y) : xAxis.left,
                translateY: inverted ? xAxis.top : yAxis.top + yAxis.len -  yAxis.translate(point.y)
            });
        }
    });
}
function degtocard(deg){
    let val = Math.floor(deg/22.5)
    let arr = ["N","NNE","NE","ENE","E","ESE", "SE", "SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"]
    return arr[val % 16]
}

function current_hours12()
{
    hour = new Date().getHours();
    if (hour > 12) return ((hour % 12) + ' PM')
    else return (hour + ' AM')
}

var windDir_gauge=function(container)
{
    // Wind Direction Gauge
    Highcharts.chart(container, {
            chart: {
                type: 'gauge',
                backgroundColor:null,
                plotBackgroundColor: null,
                plotBackgroundImage: null,
                plotBorderWidth: 0,
                plotShadow: false
            },

            title: {
                text: 'Direction',
                y: 25
            },

            pane: {
                startAngle: 0,
                endAngle: 360,
                background: [{
                    backgroundColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
                            [0, '#FFF'],
                            [1, '#333']
                        ]
                    },
                    borderWidth: 0,
                    outerRadius: '109%'
                }, {
                    backgroundColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
                            [0, '#333'],
                            [1, '#FFF']
                        ]
                    },
                    borderWidth: 1,
                    outerRadius: '107%'
                }, {
                    // default background
                }, {
                    backgroundColor: '#DDD',
                    borderWidth: 0,
                    outerRadius: '105%',
                    innerRadius: '103%'
                }]
            },
            plotOptions: {
                gauge: {
                    dial: {
                        radius: '75%',
                    }
                }
            },
            // the value axis
            yAxis: {
                min: 0,
                max: 360,
                tickWidth: 1,
                tickPosition: 'outside',
                tickLength: 20,
                tickColor: '#999',
                tickInterval:22.5,
                labels: {
                    rotation: 'auto',
                    formatter:function(){
                        return degtocard(this.value)
                    }
                },
                title: {
                    text: '°',
                    style:{fontSize: '15px'},
                    y: 140
                }},

            series: [{
                name: 'Wind Direction',
                data: windDirection,
                tooltip: {
                    pointFormatter: function() {
                        return  this.series.name + ':<b>' + this.y + '° or ' + degtocard(this.y) + '</b><br/>'
                    }
                }
            }],
            exporting: {
                enabled: false
            },
            credits: {
                enabled: false
            }
        }, function(chart){updateGaugeData(chart, windDirection);});
}

var windSpd_gauge=function(container)
{
    Highcharts.chart(container, {

            chart: {
                type: 'gauge',
                backgroundColor:null,
                plotBackgroundColor: null,
                plotBackgroundImage: null,
                plotBorderWidth: 0,
                plotShadow: false
            },

            title: {
                text: 'Wind Speed',
                y: 25
            },

            pane: {
                startAngle: -150,
                endAngle: 150,
                background: [{
                    backgroundColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
                            [0, '#FFF'],
                            [1, '#333']
                        ]
                    },
                    borderWidth: 0,
                    outerRadius: '109%'
                }, {
                    backgroundColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
                            [0, '#333'],
                            [1, '#FFF']
                        ]
                    },
                    borderWidth: 1,
                    outerRadius: '107%'
                }, {
                    // default background
                }, {
                    backgroundColor: '#DDD',
                    borderWidth: 0,
                    outerRadius: '105%',
                    innerRadius: '103%'
                }]
            },

            // the value axis
            yAxis: {
                min: 0,
                max: 400,

                minorTickInterval: 'auto',
                minorTickWidth: 1,
                minorTickLength: 10,
                minorTickPosition: 'inside',
                minorTickColor: '#666',

                tickPixelInterval: 30,
                tickWidth: 2,
                tickPosition: 'inside',
                tickLength: 10,
                tickColor: '#666',
                labels: {
                    step: 2,
                    rotation: 'auto'
                },
                title: {
                    text: 'km/h',
                    style:{fontSize: '15px'},
                    y: 140
                },
                plotBands: [{
                    from: 0,
                    to: 90,
                    color: '#55BF3B' // green
                }, {
                    from: 90,
                    to: 110,
                    color: '#DDDF0D' // yellow
                }, {
                    from: 110,
                    to: 130,
                    color: '#FF8C00' // orange
                },
                {
                    from: 130,
                    to: 400,
                    color: '#DF5353' // red
                }]
            },

            series: [{
                name: 'Wind Speed',
                data: windSpeed,
                tooltip: {
                    valueSuffix: ' km/h'
                }
            }],
            exporting: {
                enabled: false
            },
            credits: {
                enabled: false
            }

        }, function(chart) {updateGaugeData(chart, windSpeed);});
}

var pm25_gauge=function (container)
{
    Highcharts.chart(container,{

            chart: {
                type: 'gauge',
                backgroundColor:null
            },

            title: {
                text: 'PM 2.5 Concentration',
                y: 25
            },

            pane: {
                startAngle: -150,
                endAngle: 150,
                background: null
            },
            plotOptions: {
                gauge: {
                    dial: {
                        radius: '55%',
                    }
                }
            },
            // the value axis
            yAxis: {
                min: 0,
                max: 500.4,

                minorTickInterval: 'auto',
                minorTickWidth: 1,
                minorTickLength: 10,
                minorTickPosition: 'inside',
                minorTickColor:'#000000', // black

                tickPixelInterval: 25,
                tickWidth: 1,
                tickPosition: 'inside',
                tickLength: 20,
                tickColor:'#000000', // black
                labels: {
                    step: 3,
                    rotation: 'auto',
                    distance: -50
                },
                title: {
                    text: 'µg/m³',
                    style:{fontSize: '15px'},
                    y: 150
                },
                plotBands: [{
                    from: 0,
                    to: 54,
                    thickness: '25%',
                    color: '#008000' // green
                }, {
                    from: 54,
                    to: 154,
                    thickness: '25%',
                    color: '#FFFF00' // yellow
                }, {
                    from: 154,
                    to: 254,
                    thickness: '25%',
                    color: '#FF8C00' // orange
                }, {
                    from: 254,
                    to: 354,
                    thickness: '25%',
                    color: '#FF0000' // red
                },
                    {
                        from: 354,
                        to: 424,
                        thickness: '25%',
                        color: '#800080' // purple
                    },
                    {
                        from: 424,
                        to: 604,
                        thickness: '25%',
                        color: '#800000' // maroon
                    }]
            },

            series: [{
                name: 'Concentration',
                data: pm25,
                tooltip: {
                    valueSuffix: ' µg/m³'
                }
            }],
            exporting: {
                enabled: false
            },
            credits: {
                enabled: false
            }
        }, function(chart){updateGaugeData(chart, pm25);});
}

var pm10_gauge=function (container)
{
    Highcharts.chart(container,{

            chart: {
                type: 'gauge',
                backgroundColor:null,
            },

            title: {
                text: 'PM 10 Concentration',
                y: 25
            },

            pane: {
                startAngle: -150,
                endAngle: 150,
                background: null
            },

            plotOptions: {
                    gauge: {
                        dial: {
                            radius: '55%',
                        }
                    }
                },
            yAxis: {
                min: 0,
                max: 604,

                minorTickInterval: 'auto',
                minorTickWidth: 1,
                minorTickLength: 10,
                minorTickPosition: 'inside',
                minorTickColor:'#000000', // black

                tickPixelInterval: 25,
                tickWidth: 1,
                tickPosition: 'inside',
                tickLength: 20,
                tickColor:'#000000', // black
                labels: {
                    step: 3,
                    rotation: 'auto',
                    distance: -50
                },
                title: {
                    text: 'µg/m³',
                    style:{fontSize: '15px'},
                    y: 150
                },
                plotBands: [{
                    from: 0,
                    to: 54,
                    thickness: '25%',
                    color: '#008000' // green
                }, {
                    from: 54,
                    to: 154,
                    thickness: '25%',
                    color: '#FFFF00' // yellow
                }, {
                    from: 154,
                    to: 254,
                    thickness: '25%',
                    color: '#FF8C00' // orange
                }, {
                    from: 254,
                    to: 354,
                    thickness: '25%',
                    color: '#FF0000' // red
                },
                {
                    from: 354,
                    to: 424,
                    thickness: '25%',
                    color: '#800080' // purple
                },
                {
                    from: 424,
                    to: 604,
                    thickness: '25%',
                    color: '#800000' // maroon
                }]
            },

            series: [{
                name: 'Concentration',
                data: pm10,
                tooltip: {
                    valueSuffix: ' µg/m³'
                }
            }],
            exporting: {
                enabled: false
            },
            credits: {
                enabled: false
            },
        }, function(chart){updateGaugeData(chart, pm10);});
}

var aqi25_gauge=function(container)
{
    Highcharts.chart(container,{
            chart: {

                type: 'lineargauge',
                backgroundColor:null,
                inverted: true,
                height: 100,
            },
            title: {
                text: 'PM 2.5 Air Quality Index',
            },
            xAxis: {
                categories: [null],
                lineColor: '#000000',
                labels: {
                    enabled: false
                },
                tickLength: 0
            },
            yAxis: {
                min: 0,
                max: 500,
                tickLength: 6,
                tickWidth: 1,
                tickColor: '#000000',
                gridLineColor: '#000000',
                gridLineWidth: 1,
                minorTickInterval: 5,
                minorTickWidth: 1,
                minorTickLength: 4,
                minorTickColor:'#696969', // dim grey
                minorGridLineWidth: 0,
                tickPositions: [ 0, 50, 100, 150, 200, 300, 500],

                title: null,
                labels: {
                    format: '{value}'
                },
                plotBands: [{
                    from: 0,
                    to: 50,
                    color: '#008000' // green
                }, {
                    from: 51,
                    to: 100,
                    color: '#FFFF00' // yellow
                }, {
                    from: 101,
                    to: 150,
                    color: '#FF8C00' // orange
                }, {
                    from: 151,
                    to: 200,
                    color: '#FF0000' // red
                },
                    {
                        from: 201,
                        to: 300,
                        color: '#800080' // purple
                    },
                    {
                        from: 301,
                        to: 500,
                        color: '#800000' // maroon
                    }]
            },
            legend: {
                enabled: false
            },

            series: [{
                name:"AQI",
                data: aqi25,
                color: '#000000',
                dataLabels: {
                    enabled: true,
                    align: 'center',
                    format: '{point.y}',
                    y: 15,
                }
            }],
            exporting: {
                enabled: false
            },
            credits: {
                enabled: false
            },
        }, function(chart){updateGaugeData(chart, aqi25);});
}

var aqi10_gauge=function (container)
{
    Highcharts.chart(container,{
            chart: {
                type: 'lineargauge',
                backgroundColor:null,
                inverted: true,
                height: 100
            },
            title: {
                text: 'PM 10 Air Quality Index '
            },
            xAxis: {
                categories: [null],
                lineColor: '#000000',
                labels: {
                    enabled: false
                },
                tickLength: 0
            },
            yAxis: {
                min: 0,
                max: 500,
                tickLength: 6,
                tickWidth: 1,
                tickColor: '#000000',
                gridLineColor: '#000000',
                gridLineWidth: 1,
                minorTickInterval: 5,
                minorTickWidth: 1,
                minorTickLength: 4,
                minorTickColor:'#696969', // dim grey
                minorGridLineWidth: 0,
                tickPositions: [ 0, 50, 100, 150, 200, 300, 500],

                title: null,
                labels: {
                    format: '{value}'
                },
                plotBands: [{
                    from: 0,
                    to: 50,
                    color: '#008000' // green
                }, {
                    from: 51,
                    to: 100,
                    color: '#FFFF00' // yellow
                }, {
                    from: 101,
                    to: 150,
                    color: '#FF8C00' // orange
                }, {
                    from: 151,
                    to: 200,
                    color: '#FF0000' // red
                },
                    {
                        from: 201,
                        to: 300,
                        color: '#800080' // purple
                    },
                    {
                        from: 301,
                        to: 500,
                        color: '#800000' // maroon
                    }]
            },
            legend: {
                enabled: false
            },

            series: [{
                name:"AQI",
                data: aqi10,
                color: '#000000',
                dataLabels: {
                    enabled: true,
                    align: 'center',
                    format: '{point.y}',
                    y: 15,
                }
            }],
            exporting: {
                enabled: false
            },
            credits: {
                enabled: false
            }
        }, function(chart){updateGaugeData(chart, aqi10);});
}

var rain_gauge=function (container)
{
    Highcharts.chart(container,{
            chart: {
                type: 'lineargauge',
                backgroundColor:null,
                inverted: false,
            },
            title: {
                text: 'Rain Collected' + '<br> Since ' + current_hours12() + '</br>',
            },
            xAxis: {
                categories: [null],
                lineColor: '#000000',
                tickLength: 0,
                labels: {
                    enabled: false
                },
                width: 100,
            },
            yAxis: {
                min: 0,
                max: 80,
                tickPosition: 'inside',
                tickLength: 60,
                tickInterval: 20,
                tickWidth: 2,
                tickColor: '#000000', // black
                gridLineColor: '#000000', // black
                gridLineWidth: 0,
                minorTickPosition: 'inside',
                minorTickInterval: 5,
                minorTickWidth: 1,
                minorTickLength: 40,
                minorTickColor:'#000000', // black
                minorGridLineWidth: 0,

                title: {
                    text: 'mm',
                    style:{fontSize: '15px'},
                },
                labels: {
                    format: '{value}'
                },
                plotBands: [{
                    from: 0,
                    to: 7.5,
                    color: '#008000' // green
                }, {
                    from: 7.5,
                    to: 15,
                    color: '#FFFF00' // yellow
                }, {
                    from: 15,
                    to: 30,
                    color: '#FF8C00' // orange
                }, {
                    from: 30,
                    to: 80,
                    color: '#FF0000' // red
                }]
            },
            legend: {
                enabled: false
            },
            series: [{
                name:"Rainfall",
                data: rainfall,
                color: '#000000',
                dataLabels: {
                    enabled: true,
                    align: 'center',
                    format: '{point.y}',
                },
                tooltip: {
                    valueSuffix: ' mm'
                }
            }],
            exporting: {
                enabled: false
            },
            credits: {
                enabled: false
            },
        }, function(chart){updateGaugeData(chart, rainfall);});
}

var pressure_gauge=function (container)
{
    Highcharts.chart(container,{
            chart: {
                    type: 'solidgauge',
                    backgroundColor:null
                },
            title:
                {
                    text: "Atmospheric Pressure",
                    y: 25
                },
            pane: {
                size: '75%',
                startAngle: -90,
                endAngle: 90,
                background: {
                    backgroundColor: Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0.3).get(),
                    innerRadius: '60%',
                    outerRadius: '100%',
                    shape: 'arc'
                }
            },
            // the value axis
            yAxis:{
                min: 300,
                max: 1100,

                stops: [
                    [0, '#00BFFF'], // blue
                    [0.89, '#55BF3B'], // green
                    [0.92, '#DDDF0D'], // yellow
                    [0.95, '#DF5353'] // red
                ],
                lineWidth: 0,
                minorTickInterval: null,
                tickAmount: 5,
                title: {
                    text: 'hPa',
                    style:{fontSize: '15px'},
                    y: 65
                },

                labels: {
                    enabled: true,
                    distance: 15,
                    format: '{value}',
                }
            },
            series: [{
                name:"Pressure",
                data: pressure,
                dataLabels: {
                    enabled: true,
                    y: -40,
                }
            }],
            exporting: {
                enabled: false
            },
            credits: {
                enabled: false
            }
        }, function(chart){updateGaugeData(chart, pressure);});
}

var humidity_gauge=function (container)
{
    Highcharts.chart(container,{
            chart: {
                type: 'solidgauge',
                backgroundColor:null
            },
            title:
                {
                    text: "Relative Humidity",
                    y:25
                },
            pane: {
                size: '75%',
                startAngle: -90,
                endAngle: 90,
                background: {
                    backgroundColor: Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0.3).get(),
                    innerRadius: '60%',
                    outerRadius: '100%',
                    shape: 'arc'
                }
            },
            yAxis:{
                min: 0,
                max: 100,
                stops: [
                    [0, '#00BFFF'], // blue
                    [0.89, '#55BF3B'], // green
                    [0.92, '#DDDF0D'], // yellow
                    [0.95, '#DF5353'] // red
                ],
                lineWidth: 0,
                minorTickInterval: null,
                tickAmount: 5,
                title: {
                    text: '%',
                    style:{fontSize: '15px'},
                    y: 65
                },

                labels: {
                    enabled: true,
                    distance: 15,
                    format: '{value}',
                }
            },
            series: [{
                name:"Humidity",
                data: humidity,
                dataLabels: {
                    enabled: true,
                    y: -40,
                },
                tooltip: {
                    valueSuffix: ' %'
                }
            }],
            exporting: {
                enabled: false
            },
            credits: {
                enabled: false
            }
        }, function(chart){updateGaugeData(chart, humidity);});
}

var temperature_gauge=function (container)
{
    Highcharts.chart(container,{
            chart: {
                type: 'solidgauge',
                backgroundColor:null
            },
            title:
                {
                    text: "Ambient Temperature",
                    y: 25
                },
            pane: {
                size: '75%',
                startAngle: -90,
                endAngle: 90,
                background: {
                    backgroundColor: Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0.3).get(),
                    innerRadius: '60%',
                    outerRadius: '100%',
                    shape: 'arc'
                }
            },
            // the value axis
            yAxis:{
                min: -40,
                max: 85,
                stops: [
                    [0, '#00BFFF'], // blue
                    [0.89, '#55BF3B'], // green
                    [0.92, '#DDDF0D'], // yellow
                    [0.95, '#DF5353'] // red
                ],
                lineWidth: 0,
                minorTickInterval: null,
                tickAmount: 5,
                title: {
                    text: '°C',
                    style:{fontSize: '15px'},
                    y: 65
                },

                labels: {
                    enabled: true,
                    distance: 15,
                    format: '{value}',
                }
            },
            series: [{
                name:"Temperature",
                data: temperature,
                dataLabels: {
                    enabled: true,
                    y: -40,
                },
                tooltip: {
                    valueSuffix: ' °C'
                }
            }],
            exporting: {
                enabled: false
            },
            credits: {
                enabled: false
            }
        }, function(chart){updateGaugeData(chart, temperature);});
}

var uv_gauge=function (container)
{
    Highcharts.chart(container,{

        chart: {
            type: 'gauge',
            backgroundColor:null,
            plotBackgroundColor: null,
            plotBackgroundImage: null,
            plotBorderWidth: 0,
            plotShadow: false
        },

        title: {
            text: 'Current UV Index',
            y: 25
        },

        pane: {
            startAngle: -130,
            endAngle: 130,
            background: {
                backgroundColor: null,
                borderWidth: 0,
                outerRadius: '0%',
                innerRadius: '150%'
            }
        },

        // the value axis
        yAxis: {
            min: 0,
            max: 12,

            minorTickInterval: 'auto',
            minorTickWidth: 0,
            minorTickLength: 0,
            minorTickPosition: 'inside',
            minorTickColor: '#666',

            tickPixelInterval: 30,
            tickWidth: 0,
            tickPosition: 'outside',
            tickLength: 0,
            tickColor: '#666',
            labels: {
                step: 1,
                rotation: 'auto',
                distance: 10
            },

            plotBands: [{
                from: 0,
                to: 2,
                color: '#65CC1E', // green
                outerRadius: '100%',
                thickness: '75%'
            }, {
                from: 2,
                to: 5,
                color: '#FFDE32', // yellow
                outerRadius: '100%',
                thickness: '75%'
            }, {
                from: 5,
                to: 7,
                color: '#FFA500', // orange
                outerRadius: '100%',
                thickness: '75%'
            }, {
                from: 7,
                to: 10,
                color: '#FF0606', // red
                outerRadius: '100%',
                thickness: '75%'
            }, {
                from: 10,
                to: 12,
                color: '#9572FF', // purple
                outerRadius: '100%',
                thickness: '75%'

            }]
        },

        plotOptions: {
            gauge: {
                dial: {
                    radius: '90%',

                }
            }
        },

        series: [{
            name: 'UV Index',
            data: uv,
            tooltip: {
                valueSuffix: ''
            }
        }],

        exporting: {
            enabled: false
        },
        credits: {
            enabled: false
        }
    }, function(chart){updateGaugeData(chart, uv);});
}


function loadGauge(gauge, container, textColour="red") {
    initcollapse();
    setupLinearGauges(Highcharts);
    setTextColour(textColour);
    gauge(container);
}

function loadFromData(dataset){
  windSpeed[0] = parseFloat(dataset['windSpeed'].toFixed(2));
  windDirection[0] = parseFloat(dataset['windDirection'].toFixed(1));
  aqi10[0] = parseFloat(dataset['airQuality']['aqi10'].toFixed(1));
  aqi25[0] = parseFloat(dataset['airQuality']['aqi2_5'].toFixed(1));
  pm10[0] = parseFloat(dataset['airQuality']['pm10'].toFixed(1));
  pm25[0] = parseFloat(dataset['airQuality']['pm2_5'].toFixed(1));
  rainfall[0] = parseFloat(dataset['rainfall'].toFixed(1));
  pressure[0] = parseFloat(dataset['barometricPressure'].toFixed(1));
  humidity[0] = parseFloat(dataset['humidity'].toFixed(1));
  temperature[0] = parseFloat(dataset['airTemperature'].toFixed(1));
  uv[0] = parseFloat(dataset['uvIndex'].toFixed(1));
}
	


