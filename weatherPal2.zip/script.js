//sidenav
  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.sidenav');
    var instances = M.Sidenav.init(elems, {});
  });

  //
//   window.onload = () => { 
// 'use strict';     
// if ('serviceWorker' in navigator) {     
// navigator.serviceWorker  
// .register('/sw.js'); 
// } 
// }
// console.log("service worker running");

//Tabs initialization
// var instance = M.Tabs.init(el, {swipeable:True});
// instance.updateTabIndicator();
// instance.destroy();


//Jquery for swipeable tabs and parrallax
$(document).ready(function(){
    $('ul.tabs').tabs({
      swipeable : true,
      responsiveThreshold : 1920
    });
    
    $('.parallax').parallax();
  });